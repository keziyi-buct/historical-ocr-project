from flask import Flask, render_template, request, jsonify, url_for
import os
import base64
import requests
from langchain_deepseek import ChatDeepSeek
from typing import Dict, Any
from werkzeug.utils import secure_filename
from PIL import Image
import io
import time

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'  # 使用正斜杠
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max-limit

# 确保上传文件夹存在
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# 允许的文件扩展名
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

# 使用固定的access_token
BAIDU_ACCESS_TOKEN = "24.081096eaf8d4fc4da0e1673c768b1c71.2592000.1751519898.282335-119109042"

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def extract_text_from_image(image_path: str) -> Dict[str, Any]:
    """使用百度OCR从图片中提取文字"""
    request_url = "https://aip.baidubce.com/rest/2.0/ocr/v1/accurate"
    
    # 读取图片文件并转为base64
    with open(image_path, 'rb') as f:
        img = base64.b64encode(f.read())

    # 设置请求参数
    params = {"image": img}
    request_url = f"{request_url}?access_token={BAIDU_ACCESS_TOKEN}"
    headers = {'content-type': 'application/x-www-form-urlencoded'}

    # 发送OCR请求
    response = requests.post(request_url, data=params, headers=headers)
    if response:
        return response.json()
    raise Exception("OCR识别失败")

def process_ocr_result(ocr_result: Dict[str, Any]) -> str:
    """处理OCR结果，提取所有文字内容"""
    if 'words_result' not in ocr_result:
        return ""
    
    # 提取所有识别出的文字
    text = ""
    for word in ocr_result['words_result']:
        if 'words' in word:
            text += word['words'] + "\n"
    return text.strip()

def format_text_with_deepseek(text: str) -> str:
    """使用DeepSeek对文本进行整理和分段"""
    # 初始化DeepSeek客户端
    llm = ChatDeepSeek(
        model="deepseek-chat",
        api_key="sk-0838692af6684aa082ba0c7249d566cf"
    )
    
    # 构造提示词
    prompt = f"""请帮我将下面的文字整理成易读的格式，划分标点，按照内容逻辑分段，保持原文原字：

{text}

请直接返回整理后的文字，不需要其他解释。"""

    # 获取响应
    response = llm.invoke(prompt)
    return response.content

def resize_image(image_path, max_width=800, max_height=600):
    """调整图片大小以适应界面"""
    try:
        with Image.open(image_path) as img:
            # 如果图片是RGBA模式，转换为RGB
            if img.mode == 'RGBA':
                img = img.convert('RGB')
            
            # 计算调整后的尺寸，保持宽高比
            width, height = img.size
            if width > max_width or height > max_height:
                ratio = min(max_width / width, max_height / height)
                new_width = int(width * ratio)
                new_height = int(height * ratio)
                img = img.resize((new_width, new_height), Image.LANCZOS)
            
            # 生成调整后的文件名，使用时间戳确保唯一性
            timestamp = int(time.time())
            filename = os.path.basename(image_path)
            name, ext = os.path.splitext(filename)
            resized_filename = f"{name}_resized_{timestamp}{ext}"
            
            # 使用正斜杠构建路径
            resized_path = os.path.join(app.config['UPLOAD_FOLDER'], resized_filename).replace('\\', '/')
            
            # 保存调整后的图片
            img.save(resized_path, quality=95, optimize=True)
            return resized_path
    except Exception as e:
        print(f"调整图片大小时出错: {e}")
        return image_path  # 如果出错，返回原始路径

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def process_image():
    if 'file' not in request.files:
        return jsonify({'error': '没有上传文件'})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': '没有选择文件'})
    
    if not allowed_file(file.filename):
        return jsonify({'error': '不支持的文件类型'})
    
    try:
        # 保存上传的文件
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename).replace('\\', '/')
        file.save(filepath)
        
        # 调整图片大小
        resized_filepath = resize_image(filepath)
        
        # OCR识别
        ocr_result = extract_text_from_image(filepath)  # 使用原始图片进行OCR
        raw_text = process_ocr_result(ocr_result)
        
        if not raw_text:
            return jsonify({
                'error': '未能从图片中提取到文字',
                'image_path': '/' + resized_filepath  # 确保路径格式正确
            })
        
        # DeepSeek处理
        formatted_text = format_text_with_deepseek(raw_text)
        
        # 构建正确的图片URL
        image_url = '/' + resized_filepath
            
        return jsonify({
            'success': True,
            'image_path': image_url,
            'raw_text': raw_text,
            'formatted_text': formatted_text
        })
        
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')