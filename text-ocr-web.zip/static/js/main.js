document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('upload-form');
    const fileInput = document.getElementById('file-input');
    const fileSelectName = document.getElementById('noFile');
    const loading = document.getElementById('loading');
    const resultSection = document.getElementById('result-section');
    const errorMessage = document.getElementById('error-message');
    const originalImage = document.getElementById('original-image');
    const rawText = document.getElementById('raw-text');
    const formattedText = document.getElementById('formatted-text');

    // 图片加载错误处理
    originalImage.addEventListener('error', function() {
        console.error('图片加载失败:', this.src);
        this.style.display = 'none';
        const container = this.parentElement;
        if (!container.querySelector('.image-error')) {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'image-error';
            errorDiv.textContent = '图片加载失败，路径: ' + this.src;
            container.appendChild(errorDiv);
        }
    });

    // 图片加载成功处理
    originalImage.addEventListener('load', function() {
        console.log('图片加载成功:', this.src);
        this.style.display = 'block';
        const errorDiv = this.parentElement.querySelector('.image-error');
        if (errorDiv) {
            errorDiv.remove();
        }
    });

    // 文件选择处理
    fileInput.addEventListener('change', function() {
        if (this.files && this.files[0]) {
            fileSelectName.textContent = this.files[0].name;
            // 清除之前的结果和错误信息
            resultSection.style.display = 'none';
            errorMessage.style.display = 'none';
            // 清除之前的图片
            originalImage.src = '';
            const errorDiv = originalImage.parentElement.querySelector('.image-error');
            if (errorDiv) {
                errorDiv.remove();
            }
        } else {
            fileSelectName.textContent = '未选择文件...';
        }
    });

    // 表单提交处理
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        // 检查是否选择了文件
        if (!fileInput.files || !fileInput.files[0]) {
            showError('请选择要上传的图片');
            return;
        }

        // 检查文件类型
        const file = fileInput.files[0];
        const fileType = file.type;
        if (!['image/jpeg', 'image/jpg', 'image/png'].includes(fileType)) {
            showError('请选择 JPG 或 PNG 格式的图片');
            return;
        }

        // 显示加载动画
        loading.style.display = 'block';
        resultSection.style.display = 'none';
        errorMessage.style.display = 'none';

        // 创建FormData对象
        const formData = new FormData();
        formData.append('file', file);

        // 发送AJAX请求
        fetch('/process', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            loading.style.display = 'none';

            if (data.error) {
                showError(data.error);
                return;
            }

            console.log('收到的图片路径:', data.image_path);
            
            // 直接使用服务器返回的图片路径，不做额外处理
            originalImage.src = data.image_path;
            
            rawText.textContent = data.raw_text;
            formattedText.innerHTML = data.formatted_text.replace(/\n/g, '<br>');
            resultSection.style.display = 'block';

            // 滚动到结果区域
            resultSection.scrollIntoView({ behavior: 'smooth' });
        })
        .catch(error => {
            loading.style.display = 'none';
            showError('处理请求时出错：' + error.message);
        });
    });

    // 显示错误信息
    function showError(message) {
        errorMessage.textContent = message;
        errorMessage.style.display = 'block';
        errorMessage.scrollIntoView({ behavior: 'smooth' });
    }

    // 拖放文件处理
    const dropZone = document.querySelector('.file-select');

    dropZone.addEventListener('dragover', function(e) {
        e.preventDefault();
        this.style.borderColor = '#3498db';
        this.style.background = '#f0f9ff';
    });

    dropZone.addEventListener('dragleave', function(e) {
        e.preventDefault();
        this.style.borderColor = '#dcdcdc';
        this.style.background = '#f9f9f9';
    });

    dropZone.addEventListener('drop', function(e) {
        e.preventDefault();
        this.style.borderColor = '#dcdcdc';
        this.style.background = '#f9f9f9';

        const files = e.dataTransfer.files;
        if (files.length) {
            fileInput.files = files;
            fileSelectName.textContent = files[0].name;
            // 清除之前的结果和错误信息
            resultSection.style.display = 'none';
            errorMessage.style.display = 'none';
            // 清除之前的图片
            originalImage.src = '';
            const errorDiv = originalImage.parentElement.querySelector('.image-error');
            if (errorDiv) {
                errorDiv.remove();
            }
        }
    });
});