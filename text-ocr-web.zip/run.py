import os
from app import app

if __name__ == '__main__':
    # 确保上传文件夹存在
    os.makedirs('static/uploads', exist_ok=True)
    
    # 启动应用
    app.run(debug=True, host='0.0.0.0', port=5000)