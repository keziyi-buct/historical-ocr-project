# 古文OCR识别与整理系统

这是一个基于Flask的Web应用，用于古文图片的OCR文字识别和智能排版整理。系统使用百度OCR API进行文字识别，使用DeepSeek进行文本智能排版。

## 功能特点

- 支持图片上传（JPG、JPEG、PNG格式）
- 自动调整图片大小以适应显示
- OCR文字识别
- DeepSeek智能排版
- 响应式界面设计
- 拖放文件上传支持

## 安装说明

1. 安装依赖：
```bash
pip install -r requirements.txt
```

2. 确保系统中已安装以下Python包：
- Flask
- requests
- Pillow
- langchain-deepseek
- python-dotenv

## 运行应用

1. 进入项目目录：
```bash
cd text-ocr-web
```

2. 运行应用：
```bash
python run.py
```

3. 在浏览器中访问：
```
http://localhost:5000
```

## 使用说明

1. 上传图片：
   - 点击"选择图片"按钮选择文件
   - 或直接将图片拖放到上传区域

2. 处理图片：
   - 点击"上传并处理"按钮
   - 等待处理完成

3. 查看结果：
   - 左侧显示原始图片（已自动调整大小）
   - 中间显示OCR识别的原始文本
   - 右侧显示DeepSeek整理后的文本

## 注意事项

1. 图片要求：
   - 支持的格式：JPG、JPEG、PNG
   - 最大文件大小：16MB
   - 建议使用清晰的图片以获得更好的识别效果

2. API密钥：
   - 使用固定的百度OCR access_token
   - 使用预设的DeepSeek API密钥

3. 图片处理：
   - 上传的图片会自动调整大小以适应显示
   - 原始图片会保存在static/uploads目录下

## 目录结构

```
text-ocr-web/
├── app.py              # Flask应用主文件
├── run.py             # 启动脚本
├── requirements.txt    # 依赖列表
├── README.md          # 说明文档
├── static/
│   ├── css/
│   │   └── style.css   # 样式文件
│   ├── js/
│   │   └── main.js     # JavaScript交互脚本
│   └── uploads/        # 上传图片存储目录
└── templates/
    └── index.html      # 主页面模板
```

## 技术栈

- 后端：Python Flask
- 前端：HTML5 + CSS3 + JavaScript
- API：百度OCR + DeepSeek
- 图片处理：Pillow

## 问题排查

1. 如果图片无法显示：
   - 检查uploads目录权限
   - 确认图片路径正确
   - 查看浏览器控制台错误信息

2. 如果OCR识别失败：
   - 确认百度OCR access_token是否有效
   - 检查图片格式和大小是否符合要求

3. 如果DeepSeek处理失败：
   - 确认API密钥是否有效
   - 检查网络连接状态

## 更新日志

### v1.0.0
- 初始版本发布
- 支持基本的OCR识别和文本整理功能
- 添加图片自动调整大小功能
- 优化界面显示效果